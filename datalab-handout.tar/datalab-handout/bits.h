//1
long bitMatch(long, long);
long test_bitMatch(long, long);
//2
long implication(long, long);
long test_implication(long, long);
long leastBitPos(long);
long test_leastBitPos(long);
long oddBits(void);
long test_oddBits(void);
long dividePower2(long, long);
long test_dividePower2(long, long);
//3
long isLessOrEqual(long, long);
long test_isLessOrEqual(long, long);
long rotateLeft(long, long);
long test_rotateLeft(long, long);
long conditional(long, long, long);
long test_conditional(long, long, long);
long isLess(long, long);
long test_isLess(long, long);
//4
long isPalindrome(long);
long test_isPalindrome(long);
long trueThreeFourths(long);
long test_trueThreeFourths(long);
long howManyBits(long);
long test_howManyBits(long);
